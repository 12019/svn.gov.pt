#!/bin/bash
install -m 755 -p "lib/libpteidcommon.so.3.5.5" "/usr/local/lib/libpteidcommon.so.3.5.5"
ln -f -s /usr/local/lib/libpteidcommon.so.3.5.5 /usr/local/lib/libpteidcommon.so
ln -f -s /usr/local/lib/libpteidcommon.so.3.5.5 /usr/local/lib/libpteidcommon.so.3
ln -f -s /usr/local/lib/libpteidcommon.so.3.5.5 /usr/local/lib/libpteidcommon.so.3.5
install -m 755 -p "lib/libpteiddialogsQT.so.3.5.5" "/usr/local/lib/libpteiddialogsQT.so.3.5.5"
ln -s -f /usr/local/lib/libpteiddialogsQT.so.3.5.5 /usr/local/lib/libpteiddialogsQT.so
ln -s -f /usr/local/lib/libpteiddialogsQT.so.3.5.5 /usr/local/lib/libpteiddialogsQT.so.3
ln -s -f /usr/local/lib/libpteiddialogsQT.so.3.5.5 /usr/local/lib/libpteiddialogsQT.so.3.5
install -m 755 -p "bin/pteiddialogsQTsrv" "/usr/local/bin/pteiddialogsQTsrv"
install -m 755 -p "lib/libpteidcardlayer.so.3.5.5" "/usr/local/lib/libpteidcardlayer.so.3.5.5"
ln -s -f /usr/local/lib/libpteidcardlayer.so.3.5.5 /usr/local/lib/libpteidcardlayer.so
ln -s -f /usr/local/lib/libpteidcardlayer.so.3.5.5 /usr/local/lib/libpteidcardlayer.so.3
ln -s -f /usr/local/lib/libpteidcardlayer.so.3.5.5 /usr/local/lib/libpteidcardlayer.so.3.5
install -m 755 -p "lib/libcardpluginPteid.so.3.0.1" "/usr/local/lib/libcardpluginPteid.so.3.0.1"
ln -s -f /usr/local/lib/libcardpluginPteid.so.3.0.1 /usr/local/lib/libcardpluginPteid.so
ln -s -f /usr/local/lib/libcardpluginPteid.so.3.0.1 /usr/local/lib/libcardpluginPteid.so.3
ln -s -f /usr/local/lib/libcardpluginPteid.so.3.0.1 /usr/local/lib/libcardpluginPteid.so.3.0
install -m 755 -p "lib/libcardpluginFull__ACS__.so.3.5.5" "/usr/local/lib/libcardpluginFull__ACS__.so.3.5.5"
ln -s -f /usr/local/lib/libcardpluginFull__ACS__.so.3.5.5 /usr/local/lib/libcardpluginFull__ACS__.so
ln -s -f /usr/local/lib/libcardpluginFull__ACS__.so.3.5.5 /usr/local/lib/libcardpluginFull__ACS__.so.3
ln -s -f /usr/local/lib/libcardpluginFull__ACS__.so.3.5.5 /usr/local/lib/libcardpluginFull__ACS__.so.3.5
install -m 755 -p "lib/libsiscardplugin1__ACS__.so.3.5.5" "/usr/local/lib/libsiscardplugin1__ACS__.so.3.5.5"
ln -s -f /usr/local/lib/libsiscardplugin1__ACS__.so.3.5.5 /usr/local/lib/libsiscardplugin1__ACS__.so
ln -s -f /usr/local/lib/libsiscardplugin1__ACS__.so.3.5.5 /usr/local/lib/libsiscardplugin1__ACS__.so.3 
ln -s -f /usr/local/lib/libsiscardplugin1__ACS__.so.3.5.5 /usr/local/lib/libsiscardplugin1__ACS__.so.3.5
install -m 755 -p "lib/libpteidpkcs11.so.3.5.5" "/usr/local/lib/libpteidpkcs11.so.3.5.5"
ln -s -f /usr/local/lib/libpteidpkcs11.so.3.5.5 /usr/local/lib/libpteidpkcs11.so
ln -s -f /usr/local/lib/libpteidpkcs11.so.3.5.5 /usr/local/lib/libpteidpkcs11.so.3
ln -s -f /usr/local/lib/libpteidpkcs11.so.3.5.5 /usr/local/lib/libpteidpkcs11.so.3.5
install -m 755 -p "lib/libpteidapplayer.so.3.5.5" "/usr/local/lib/libpteidapplayer.so.3.5.5"
ln -s -f /usr/local/lib/libpteidapplayer.so.3.5.5 /usr/local/lib/libpteidapplayer.so
ln -s -f /usr/local/lib/libpteidapplayer.so.3.5.5 /usr/local/lib/libpteidapplayer.so.3
ln -s -f /usr/local/lib/libpteidapplayer.so.3.5.5 /usr/local/lib/libpteidapplayer.so.3.5
install -m 755 -p "lib/libpteidlib.so.3.5.5" "/usr/local/lib/libpteidlib.so.3.5.5"
ln -s -f /usr/local/lib/libpteidlib.so.3.5.5 /usr/local/lib/libpteidlib.so
ln -s -f /usr/local/lib/libpteidlib.so.3.5.5 /usr/local/lib/libpteidlib.so.3
ln -s -f /usr/local/lib/libpteidlib.so.3.5.5 /usr/local/lib/libpteidlib.so.3.5
install -m 755 -p "lib/libpteidlibJava_Wrapper.so.3.5.5" "/usr/local/lib/libpteidlibJava_Wrapper.so.3.5.5"
ln -s -f /usr/local/lib/libpteidlibJava_Wrapper.so.3.5.5 /usr/local/lib/libpteidlibJava_Wrapper.so
ln -s -f /usr/local/lib/libpteidlibJava_Wrapper.so.3.5.5 /usr/local/lib/libpteidlibJava_Wrapper.so.3
ln -s -f /usr/local/lib/libpteidlibJava_Wrapper.so.3.5.5 /usr/local/lib/libpteidlibJava_Wrapper.so.3.5
install -m 755 -p "bin/pteidgui" "/usr/local/bin/pteidgui"

install -m 644 -p "eidgui/eidmw_de.qm" "/usr/local/bin/"
install -m 644 -p "eidgui/eidmw_en.qm" "/usr/local/bin/"
install -m 644 -p "eidgui/eidmw_fr.qm" "/usr/local/bin/"
install -m 644 -p "eidgui/eidmw_nl.qm" "/usr/local/bin/"
echo "Finish!"
