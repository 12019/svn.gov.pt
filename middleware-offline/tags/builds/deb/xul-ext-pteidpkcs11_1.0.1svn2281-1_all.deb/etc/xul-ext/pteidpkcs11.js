// Place your preferences for xul-ext-pteidpkcs11 in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/pteidpkcs11/defaults/preferences/portugaleid.js
