// Place your preferences for xul-ext-pteidcertinstall in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/pteidcertinstall/defaults/preferences/firefox-cck.js
