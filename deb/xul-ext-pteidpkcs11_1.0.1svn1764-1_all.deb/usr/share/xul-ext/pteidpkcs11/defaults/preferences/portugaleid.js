pref("extensions.portugaleid.modulename", "Portugal eID PKCS#11 Module");

pref("extensions.portugaleid.modulelocation", "pteidpkcs11.dll;libpteidpkcs11.so;/Library/Frameworks/BeId.framework/Versions/4.0/lib/libpteidpkcs11.dylib;/usr/local/lib/pteid-pkcs11.bundle;/usr/local/lib/pteid-pkcs11.bundle/Contents/MacOS/libpteidpkcs11.dylib;/usr/local/lib/libpteidpkcs11.so");
pref("extensions.portugaleid.showmodulenotfoundnotification", true);
